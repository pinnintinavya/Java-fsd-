package my_accessmodifiers;

public class Student {

	
		public int rollNo =101;
		public Student()
		{
			rollNo=102;
		}
		public void printRollNumber()
		{
			System.out.println(rollNo);
		}
		
		

	}


