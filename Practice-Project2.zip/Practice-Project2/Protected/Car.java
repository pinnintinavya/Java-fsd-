package my_accessmodifiers;

public class Car  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student();
		System.out.println(s.rollNo);
		s.printRollNumber();
		
	}
   
}
