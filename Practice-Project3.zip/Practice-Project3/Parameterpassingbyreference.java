package my_methods;

public class Parameterpassingbyreference {
	int x;
	int y;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parameterpassingbyreference p1=new Parameterpassingbyreference();
        p1.x=1;
        p1.y=2;
        System.out.println("x= " + p1.x +",y=" +p1.y);
        change(p1);
        System.out.println("x= " + p1.x +",y=" +p1.y);
	}
    private static void change(Parameterpassingbyreference p)
    {
    	p.x=2;
    	p.y=1;
    }
}
