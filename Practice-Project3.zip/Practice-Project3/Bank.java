package my_methods;

public class Bank {
	        
	         static int currentBalance=1000;
	         
	         public static void greetCustomer()
	         {
	        	 System.out.println("Hello,Welcome to the Banking Application");
	         }
	        
	         public void deposit(int amount)
	         {
	        	 currentBalance=currentBalance+amount;
	        	 System.out.println("Amount Credited Successfully");
	         }
	         public static void withdrawal(int amount)
	         {
	        	 currentBalance=currentBalance-amount;
	        	 System.out.println("Amount Dedited Successfully");
	         }
	         public int getCurrentBalance()
	         {
	        	 return currentBalance;
	         }
	         public static void main(String[] args)
	         {
	        	 //Calling a Method
	        	 
	        	 Bank b=new Bank();
	        	 greetCustomer();
	        	 System.out.println("Current Balance is:"+currentBalance);
	        	 b.deposit(500);
	        	 System.out.println("Current Balance is:"+b.getCurrentBalance());
	        	 withdrawal(300);//Static method calling
	        	 System.out.println("Current Balance is:"+b.getCurrentBalance());
	        	 
	        	 
	         }
	         
	}


