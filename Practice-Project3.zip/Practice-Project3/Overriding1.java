package my_methods;

class A
{
	public int add(int n1,int n2)
	{
		return n1+n2;
	}
	
}

class B extends A
{
	public int add(int n1,int n2)
	{
		return n1+n2+1;
	}
}
public class Overriding1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		int r1=obj.add(7, 2);
		System.out.println(r1);
	}

}
