package my_maps;
import java.util.*;

public class Treemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("-----TreeMap-----");
		TreeMap<Integer,String> tp=new TreeMap<>();
		tp.put(3, "A");
		tp.put(2, "B");
		tp.put(1, "D");
		System.out.println(tp);
	}

}
