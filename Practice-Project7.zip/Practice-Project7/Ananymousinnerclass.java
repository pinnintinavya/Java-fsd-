package mine_innerclass;
class A
{
	
	public void show()
	{ 
		System.out.println("In Show");
	}
	
}

public class Ananymousinnerclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj=new A()
		{
			public void show()
			{
				//Ananymous class
				System.out.println("In New Show");
			}
		};
		obj.show();
	}

}
