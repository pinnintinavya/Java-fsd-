package my_constructors;
public class Cuboid
{
	int width;
	int height;
	int depth;
	Cuboid(int width,int height,int depth)
	{
		this.width=width;
		this.height=height;
		this.depth=depth;
	}
	Cuboid(int width,int height)
	{
		this.width=width;
		this.height=height;
		this.depth=10;
	}
	Cuboid(int dimension)
	{
		this.width=dimension;
		this.height=dimension;
		this.depth=dimension;
	}
	Cuboid()
	{
		this.width=5;
		this.height=5;
		this.depth=5;
	}
	int volume()
	{
		return width*height*depth;
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int v;
		Cuboid c1=new Cuboid(10,5,3);
		v=c1.volume();
		System.out.println("volume of simple cuboid is:"+v);
		
		Cuboid c2=new Cuboid(3,8);
		v=c2.volume();
		System.out.println("volume of cuboid with default depth is:"+v);
		
		Cuboid c3=new Cuboid(3);
		v=c3.volume();
		System.out.println("volume of cube is:"+v);
		
		Cuboid c4=new Cuboid();
		v=c4.volume();
		System.out.println("volume of default cuboid is:"+v);
   }

}
